

<!DOCTYPE html>
<html lang="en">
<?php
session_start();

 include 'connect.php'; 
if(isset($_POST['email']) && isset($_POST['password'])){
 //Assign

$email=$_POST['email'];
$password=md5($_POST['password']);
//check record
$result=mysqli_query($conn,"select * from admin where email='$email'and password='$password'") or die(mysqli_error($conn));
$row=mysqli_fetch_array($result);


if($row !== null && strtolower($row['email'])==strtolower($email) && $row['password']==$password)
{


   
    $_SESSION['email']=$row['email'];
    $email=$_SESSION['email'];
    $_SESSION['admin_id']=$row['admin_id'];
    $id=$_SESSION['admin_id'];
   
    
echo '<script>alert("login successful.");window.location = "dashboard.php";</script>';  
    

}else
{


echo '<script>alert("User not registered with us.");window.location = "index.php";</script>';  
 exit;

}

}

?>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Stories-ACOM</title><link rel="icon" href="assets/img/logo.jpeg">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alatsi">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Alegreya+Sans">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Allerta">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Anton">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Archivo+Black">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Archivo+Narrow">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Asap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lora">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/fonts/ionicons.min.css">
    <link rel="stylesheet" href="assets/css/Animated-numbers-section.css">
    <link rel="stylesheet" href="assets/css/Animation-Cards-1.css">
    <link rel="stylesheet" href="assets/css/Animation-Cards.css">
    <link rel="stylesheet" href="assets/css/Article-Clean.css">
    <link rel="stylesheet" href="assets/css/best-carousel-slide.css">
    <link rel="stylesheet" href="assets/css/Customizable-Background--Overlay.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer-1.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer-2.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer-3.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer-4.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer-5.css">
    <link rel="stylesheet" href="assets/css/Dark-Footer.css">
    <link rel="stylesheet" href="assets/css/ebs-contact-form-1.css">
    <link rel="stylesheet" href="assets/css/ebs-contact-form.css">
    <link rel="stylesheet" href="assets/css/Footer-Basic.css">
    <link rel="stylesheet" href="assets/css/Footer-Clean.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/css/lightbox.min.css">
    <link rel="stylesheet" href="assets/css/Jumbotron-Circular-Addon.css">
    <link rel="stylesheet" href="assets/css/Lightbox-Gallery.css">
    <link rel="stylesheet" href="assets/css/Login-Center.css">
    <link rel="stylesheet" href="assets/css/Scroll-To-Top-1.css">
    <link rel="stylesheet" href="assets/css/Scroll-to-top.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/Team-1.css">
    <link rel="stylesheet" href="assets/css/Team-Boxed.css">
    <link rel="stylesheet" href="assets/css/Team-Clean.css">
    <link rel="stylesheet" href="assets/css/Team-Grid.css">
    <link rel="stylesheet" href="assets/css/Team.css">
    <link rel="stylesheet" href="assets/css/untitled-1.css">
    <link rel="stylesheet" href="assets/css/untitled-2.css">
    <link rel="stylesheet" href="assets/css/untitled-3.css">
    <link rel="stylesheet" href="assets/css/untitled.css">
</head>
<script>

    
        function validateForm() 
        {
        var uerror=document.getElementById("uerror");
        var perror=document.getElementById("perror");
        

    

        
        if(document.forms["form"]["email"].value=="" && document.forms["form"]["password"].value=="")
        {
        
        uerror.innerHTML="<span style='color:red;,font-family: Alata, sans-serif;''>"+" email address required *</span>"
        perror.innerHTML="<span style='color:red;,font-family: Alata, sans-serif;''>"+" password required *</span>"
       
        
        return false;
        
        }
        else
        {



        if(document.forms["form"]["email"].value=="")
        {
        
        uerror.innerHTML="<span style='color:red;,font-family: Alata, sans-serif''>"+" email address required *</span>"
        
        return false;
        
        }else
        {
         
            uerror.innerHTML="";

        }
  
        
        if(document.forms["form"]["password"].value=="")
        {
        
        perror.innerHTML="<span style='color:red;,font-family: Alata, sans-serif''>"+" password required *</span>"
        
        return false;
        
        }
        else
        {

            perror.innerHTML="";


        }

//
    
        }
        
        }
        </script>
<body style="border-radius: 4px;">
    <header style="height: 100%;">
        <p style="text-align: center;font-size: 30px;margin-top: 14px;font-family: 'Archivo Narrow', sans-serif;"><i class="icon ion-waterdrop" style="font-size: 26px;color: var(--yellow);"></i>&nbsp;A<span style="color: var(--yellow);">C</span>O<span style="color: var(--yellow);">M</span></p>
    </header>
    <div style="height: 250px;background: url(&quot;assets/img/pexels-anna-nekrashevich-6476118.jpg&quot;) center / cover no-repeat;margin-top: 8px;">
        <div class="d-flex justify-content-center align-items-center" style="height:inherit;min-height:initial;width:100%;position:absolute;left:0;background-color:rgba(30,41,99,0.53);">
            <div class="d-flex align-items-center order-12" style="height:200px;">
                <div class="container">
                    <h1 class="text-center" style="color: var(--yellow);font-size: 25px;font-weight: bold;">Blog (Main Admin)</h1>
                    <h1 class="text-center" style="color: var(--yellow);font-size: 25px;font-weight: bold;"><i class="fa fa-quote-left" style="color: rgb(255,255,255);"></i><span style="font-size: 16px;font-weight: 40;"><strong>&nbsp;FIND MORE STORIES&nbsp;</strong></span><i class="fa fa-quote-right" style="color: rgb(255,255,255);"></i><strong>&nbsp;</strong></h1>
                </div>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="row row-login" style="margin-right: -50px;margin-left: -50px;margin-bottom: 33px;">
            <div class="col-10 col-sm-6 col-md-4 offset-1 offset-sm-3 offset-md-4" style="margin-bottom: 24px;">
                <div class="card">
                    <div class="card-body" style="border-radius: 23px;">
                        <p style="text-align: center;font-size: 30px;margin-top: 14px;font-family: 'Archivo Narrow', sans-serif;"><i class="icon ion-waterdrop" style="font-size: 26px;color: var(--yellow);"></i>&nbsp;A<span style="color: var(--yellow);">C</span>O<span style="color: var(--yellow);">M</span>- Login</p>
                        <form name="form" action="" onsubmit="return validateForm();" method="post">
                            <div class="form-group"><label>Email</label><input class="form-control" type="text" id="email" name="email"><span id="uerror" ></span></div>
                            <div class="form-group"><label>Password </label><input class="form-control" type="password"  name="password" id="password" ><span id="perror"></span></div>
                         
                  
                            </div><button class="btn btn-block" type="submit" style="color: rgb(255,255,255);background: var(--yellow);">LOGIN </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="article-clean"></section><a href="#top">
        <div id="scroll-to-top" style="background: rgb(255,255,255);"><i class="fa fa-chevron-up" style="color: var(--yellow);"></i></div>
    </a>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/-Animated-numbers-section-BS4-.js"></script>
    <script src="assets/js/Animated-numbers-section.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightbox2/2.8.2/js/lightbox.min.js"></script>
    <script src="assets/js/Scroll-to-top.js"></script>
</body>

</html>